class Venta:

    def __init__(self, usuario, fecha, compra, cliente, total):
        self.usuario = usuario
        self.fecha = fecha
        self.compra = compra
        self.cliente = cliente
        self.total = total
