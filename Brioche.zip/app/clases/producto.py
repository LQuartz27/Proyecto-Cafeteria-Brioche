class Producto:

    def __init__(self, referencia, nombre, precio, unidades, foto):
        self.referencia = referencia
        self.nombre = nombre
        self.precio = precio
        self.unidades = unidades
        self.foto = foto
